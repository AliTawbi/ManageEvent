using EventProject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace EventProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EventController : ControllerBase
    {
       

        [HttpGet]
        public IEnumerable<EventTable> Get()
        {
            using (var context = new EventDatabaseContext()) //DbContext
            {

                List<EventTable> events = (from EventTable event_ in context.EventTables select event_).ToList();
                foreach (EventTable event_ in events)
                {//Select FILES
                    event_.FilesAttacheds = (from FilesAttached file in context.FilesAttacheds where file.EventId == event_.EventId select file).ToList();
                }
                return events;
            }
        }


        [HttpPost]//[Post]:https..../Controller
        public void Post([FromBody] EventTable value)//Add Event
        {
            using (var context = new EventDatabaseContext())
            {
                context.EventTables.Add(value);
                context.SaveChanges();

            }

        }


        [HttpDelete("{id}")] //[Delete]:https..../Controller/id
        public void Delete(int id)//delete event by id
        {
            using (var context = new EventDatabaseContext())
            {
                FilesAttached file = context.FilesAttacheds.Where(e => e.EventId == id).FirstOrDefault();
                context.FilesAttacheds.Remove(file);
                EventTable event_ = context.EventTables.Where(d => d.EventId == id).FirstOrDefault();
                context.EventTables.Remove(event_);
                context.SaveChanges();

            }

        }

        [HttpPut("{id}")]//  [Put]:https..../Controller/id
        public void Put(int id, [FromBody] EventTable value)//update event by id
        {
            using (var context = new EventDatabaseContext())
            {
                var event_ = context.EventTables.FirstOrDefault(s => s.EventId == id);
                if (event_ != null)
                          context.Entry<EventTable>(event_).CurrentValues.SetValues(value);
          {
                    context.SaveChanges();
                }
            }

        }





    }
}