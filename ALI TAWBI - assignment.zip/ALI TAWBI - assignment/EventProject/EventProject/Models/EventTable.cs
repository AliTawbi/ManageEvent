﻿using System;
using System.Collections.Generic;

namespace EventProject.Models
{
    public partial class EventTable
    {
        public EventTable()
        {
            FilesAttacheds = new HashSet<FilesAttached>();
        }

        public int EventId { get; set; }
        public string? EventTitle { get; set; }
        public DateTime? EventDate { get; set; }
        public DateTime? CreatedDate { get; set; }

        public virtual ICollection<FilesAttached> FilesAttacheds { get; set; }
    }
}
