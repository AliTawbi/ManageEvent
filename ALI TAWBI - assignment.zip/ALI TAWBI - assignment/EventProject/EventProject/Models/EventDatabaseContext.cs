﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace EventProject.Models
{
    public partial class EventDatabaseContext : DbContext
    {
        public EventDatabaseContext()
        {
        }

        public EventDatabaseContext(DbContextOptions<EventDatabaseContext> options)
            : base(options)
        {
        }

        public virtual DbSet<EventTable> EventTables { get; set; } = null!;
        public virtual DbSet<FilesAttached> FilesAttacheds { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=.;Database=EventDatabase;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EventTable>(entity =>
            {
                entity.HasKey(e => e.EventId)
                    .HasName("PK__Event_ta__FD6AEB9C140D64D3");

                entity.ToTable("Event_table");

                entity.Property(e => e.EventId).HasColumnName("Event_id");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("createdDate")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EventDate)
                    .HasColumnType("date")
                    .HasColumnName("Event_date");

                entity.Property(e => e.EventTitle)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("Event_title");
            });

            modelBuilder.Entity<FilesAttached>(entity =>
            {
                entity.HasKey(e => e.FileId)
                    .HasName("PK__Files_at__0FFECDEE7DC311A5");

                entity.ToTable("Files_attached");

                entity.Property(e => e.FileId).HasColumnName("File_id");

                entity.Property(e => e.AttachementFile).HasColumnName("Attachement_file");

                entity.Property(e => e.EventId).HasColumnName("Event_id");

                entity.HasOne(d => d.Event)
                    .WithMany(p => p.FilesAttacheds)
                    .HasForeignKey(d => d.EventId)
                    .HasConstraintName("FK__Files_att__Event__29572725");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
