﻿using System;
using System.Collections.Generic;

namespace EventProject.Models
{
    public partial class FilesAttached
    {
        public int FileId { get; set; }
        public byte[]? AttachementFile { get; set; }
        public int? EventId { get; set; }

        public virtual EventTable? Event { get; set; }
    }
}
