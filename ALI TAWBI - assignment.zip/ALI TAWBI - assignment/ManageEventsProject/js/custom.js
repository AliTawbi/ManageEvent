$( function() {
    $( ".datepicker" ).datepicker();
    getAllEvents();

});



function getAllEvents() {
    $.ajax({
        // Our sample url to make request 
        url: 'https://localhost:7045/Event',
        // Type of Request
        type: "GET",
        // Function to call when to
        // request is ok 
        success: function (res) {
            var data = res; 
            var html='';
            for(var i in data){
                html+= 
                '<div id="eventID'+data[i].eventId+'" class="row">'+
                '<div class="col-3">'+
                    '<div class="form-group">'+
                       '<label for="inputTitle">Event Title *</label>'+
                        '<input type="text" value="'+data[i].eventTitle+'" class="form-control eventTitle">'+
                    '</div>'+
                '</div>'+
                '<div class="col-3">'+
                   '<div class="form-group">'+
                        '<label for="inputDate">Created Date</label>'+
                        '<input type="text" value="'+new Date(data[i].createdDate).toLocaleDateString("en-US")+'" class="form-control createdDate" readonly>'+
                    '</div>'+
                '</div>'+
                '<div class="col-3">'+
                    '<div class="form-group">'+
                        '<label for="eventDate">Event Date *</label>'+
                        '<input type="text" value="'+new Date(data[i].eventDate).toLocaleDateString("en-US")+'" class="form-control datepicker eventDate">'+
                    '</div>'+
                '</div>'+
                '<div class="col-3">'+
                    '<div class="updateBtn">'+
                        '<span onclick="handleClick(this)" event-dataID="'+data[i].eventId+'" data-id="eventID'+data[i].eventId+'" class="btn btn-primary">Update Event</span>'+
                    '</div>'+
                '</div>'+
            '</div>';
            }
            //console.log(html);
            $('#toUpdate').html(html)
            $( ".datepicker" ).datepicker();
        },
        // Error handling 
        error: function (error) {
            console.log(`Error ${error}`);
        }
    });
}


function updateEvent(OriginID,eventTitle,createdDate,iso) {
    $.ajax({
        // Our sample url to make request 
        url: 'https://localhost:7045/Event/'+OriginID+'',
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        type: "PUT",
        data: JSON.stringify({"eventId": OriginID,"eventTitle": eventTitle, "eventDate": iso,"createdDate": "2022-05-13T14:11:31.468Z"}),
        // Function to call when to
        // request is ok 
        success: function (data) {
            var x = JSON.stringify(data);
           // alert(x);
           getAllEvents()

        },
        // Error handling 
        error: function (error) {
            //alert(error);
            getAllEvents()
        }
    });
}


function handleClick(e){
    var eventID = $(e).attr('data-id');
    var OriginID = $(e).attr('event-dataID'); 
    var eventTitle = $('#'+eventID).find('.eventTitle').val();
    var createdDate = $('#'+eventID).find('.createdDate').val();
    var eventDate = $('#'+eventID).find('.eventDate').val();
    var dateStr = eventDate;
    var date = new Date(dateStr);
    date.setDate(date.getDate() + 1);
    var iso = date.toISOString();
    updateEvent(OriginID,eventTitle,createdDate,iso)
}

function addEventFn(){
    var eventTitle = $('#inputTitle').val();
    var eventDate = $('#eventDate').val();

    var dateStr = eventDate;

    var date = new Date(dateStr);
    date.setDate(date.getDate() + 1);
    var iso = date.toISOString();


    $.ajax({
        // Our sample url to make request 
        url: 'https://localhost:7045/Event/',
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        type: "POST",
        data: JSON.stringify({"eventId": 0,"eventTitle": eventTitle, "eventDate": iso,"createdDate": "2022-05-13T14:11:31.468Z"}),
        // Function to call when to
        // request is ok 
        success: function (data) {
            getAllEvents()

        },
        // Error handling 
        error: function (error) {
            getAllEvents()
        }
    });    
}